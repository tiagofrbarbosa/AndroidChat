# Para rodar:

1) `mvn package`

2) `java -jar target/ichat-xxx.jar`

