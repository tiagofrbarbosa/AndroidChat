package br.com.caelum.ichat.model;

public class Message {
	private String text;
	private Integer id;

	public String getText() {
		return text;
	}

	public Integer getId() {
		return id;
	}

}
